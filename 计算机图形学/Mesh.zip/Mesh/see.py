import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def read_obj(file_path):
    vertices = []  # 存储顶点
    faces = []     # 存储面
    with open(file_path, 'r') as file:
        for line in file:
            if line.startswith('v '):
                # 解析顶点信息
                vertex = list(map(float, line.strip().split()[1:]))
                vertices.append(vertex)
            elif line.startswith('f '):
                # 解析面信息
                face = [int(idx.split('/')[0]) - 1 for idx in line.strip().split()[1:]]
                faces.append(face)
    return vertices, faces

# 调用示例
vertices, faces = read_obj('C:\\Users\\53009\\Desktop\\Mesh\\dinosaur_simp_80_0.obj')

def plot_3d(vertices, faces):
    vertices = np.array(vertices)  # 转换为 NumPy 数组
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # 使用 trisurf 绘制三维表面
    ax.plot_trisurf(vertices[:, 0], vertices[:, 1], faces, vertices[:, 2], alpha=0.5)
    plt.show()


# 调用示例
plot_3d(vertices, faces)