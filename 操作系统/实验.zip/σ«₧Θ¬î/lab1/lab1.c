#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <wait.h>
//进程自定义的键盘中断信号处理函数

void handler(int sig) {
    printf("进程%d被唤醒\n", getpid());
}

int main() {

    int pid1;
    int pid2;
    int running = 1;
    signal(SIGINT, handler);
    char* args1[] = { "/usr/bin/ls", "-l", NULL };
    char* args2[] = { "/usr/bin/ps", NULL, NULL };

    while (1)
    {
        pid1 = fork();
        if (pid1 == 0)//第一个子进程
        {
            pause();
            printf("首先创建的子进程%d即将执行 ls 命令\n", getpid());
            execve(args1[0], args1, NULL);

        }
        else if (pid1 > 0)//父进程
        {
            pid2 = fork();
            if (pid2 == 0)
            {
                printf("第二个创建的子进程%d即将执行 ps 命令\n", getpid());
                execve(args2[0], args2, NULL);
                //若函数调用成功 在此函数之后的代码不会执行
            }
            else if (pid2 > 0)//父进程
            {   
                waitpid(pid2, NULL, 0);
                kill(pid1, SIGINT);
                waitpid(pid1, NULL, 0);
                sleep(3);
            }
            else
            {
                printf("创建第二个子进程失败\n");
                exit(-1);
            }
        }
        else
        
        {
            printf("创建第一个子进程失败\n");
            exit(-1);
        }
    }

    printf("父进程退出\n");
    return EXIT_SUCCESS;
}
