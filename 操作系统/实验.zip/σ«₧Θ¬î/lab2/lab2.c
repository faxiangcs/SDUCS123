#include <stdio.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <pthread.h>

int x,y;
void* task1(int *);    //线程 1 执行函数原型f(x)
void* task2(int *);    //线程 2 执行函数原型f(y)
void* task3(int *);    //线程 3 执行函数原型f(x,y)
int pipe1[2],pipe2[2];   //存放第两个无名管道标号
pthread_t thrd1,thrd2,thrd3;   //存放三个线程标识

int main(int argc,char *arg[])
{
    scanf("%d %d",&x,&y);
    int ret;
    int num1,num2,num3;
    //使用 pipe()系统调用建立两个无名管道。建立不成功程序退出，执行终止
    if(pipe(pipe1) < 0)
    {
        perror("pipe1 not create"); 
        exit(EXIT_FAILURE);
    }
    if(pipe(pipe2) < 0)
    { 
        perror("pipe2 not create");
        exit(EXIT_FAILURE);
    }
    //使用 pthread_create 系统调用建立两个线程。建立不成功程序退出，执行终止
    //num1[0] = 1 ;
    num1=x;
    ret = pthread_create(&thrd1,NULL,(void *)task1,&num1); 
    if(ret){
        perror("pthread_create: task1"); 
        exit(EXIT_FAILURE);
    }

    //num2[0] = 2;
    num2=y;
    
    ret = pthread_create(&thrd2,NULL,(void *)task2,&num2); 
    if(ret){
        perror("pthread_create: task2"); 
        exit(EXIT_FAILURE);
    }
    
    num3 = 3 ;
    ret = pthread_create(&thrd3,NULL,(void *)task3,&num3); 
    if(ret){
        perror("pthread_create: task3"); 
        exit(EXIT_FAILURE);
    }
    //等待子线程退出
    pthread_join(thrd2,NULL);  
    pthread_join(thrd1,NULL);  
    pthread_join(thrd3,NULL);
    //主线程退出
    exit(EXIT_SUCCESS);
}
//线程 1 执行函数，它首先向管道1写，然后从管道2读
void* task1(int *num)
{
    long long fx[100];
    fx[1]=1;
    for(int i=2;i<=*num;i++)
    {
        fx[i]=fx[i-1]*i;
    }

    //写入管道1；
    write(pipe1[1],&fx[*num],sizeof(long long)); 
    printf("thread1 write: %lld\n",fx[*num]); 

    close(pipe1[1]);
}
//线程 2 执行函数
void* task2(int * num)
{
    long long fy[100];
    fy[1]=1;
    fy[2]=1;
    for(int i=3;i<=*num;i++)
    {
        fy[i]=fy[i-1]+fy[i-2];
    }

    //写入管道2；
    write(pipe2[1],&fy[*num],sizeof(long long)); 
    printf("thread2 write: %lld\n",fy[*num]); 

    close(pipe1[1]);
}

void* task3(int * num1)
{
    long long fx;
    long long fy;
    read(pipe1[0],&fx,sizeof(long long)); 
    read(pipe2[0],&fy,sizeof(long long)); 
    printf("thread3 read: %lld %lld\n",fx,fy);
    printf("%lld\n",fx+fy);
//读写完成后,关闭管道
    close(pipe1[0]);
    close(pipe2[0]);
}