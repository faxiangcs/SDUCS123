#include "ipc.h"


int main(int argc,char *argv[])
{
    int rate; //设置抽烟时间
    if(argv[1] != NULL)	
        rate = atoi(argv[1]);
    else 
        rate = 3;   //默认速度是3 
      

    buff1_key = 111; // 缓冲区键值
    buff2_key = 222; // 缓冲区键值
    buff3_key = 333; // 缓冲区键值
    buff_num = 2;   // 缓冲区长度
    shm_flg = IPC_CREAT | 0644;

    // 获取缓冲区使用的共享内存, buff_ptr指向缓冲区首地址
    buff1_ptr = (char*)set_shm(buff1_key, buff_num, shm_flg);
    buff2_ptr = (char*)set_shm(buff2_key, buff_num, shm_flg);
    buff3_ptr = (char*)set_shm(buff3_key, buff_num, shm_flg);


    //信号量使用的变量
    smoker1_key = 1001;	//smoker1同步信号量键值
    sem_flg = IPC_CREAT | 0644; //信号量操作权限
    sem_val = 0;
    smoker1_sem = set_sem(smoker1_key,sem_val,sem_flg);

    smoker2_key = 1002;	//smoker1同步信号量键值
    sem_flg = IPC_CREAT | 0644; //信号量操作权限
    sem_val = 0;
    smoker2_sem = set_sem(smoker2_key,sem_val,sem_flg);

    smoker3_key = 1003;	//smoker3同步信号量键值
    sem_flg = IPC_CREAT | 0644; //信号量操作权限
    sem_val = 0;
    smoker3_sem = set_sem(smoker3_key,sem_val,sem_flg);

    provider1_key=2011;
    sem_val = 1;
    provider1_sem = set_sem(provider1_key,sem_val,sem_flg);

    provider2_key=2012;
    sem_val = 1;
    provider2_sem = set_sem(provider2_key,sem_val,sem_flg);

    provider3_key=2013;
    sem_val = 1;
    provider3_sem = set_sem(provider3_key,sem_val,sem_flg);


    int pid1;
    pid1=fork();
    
    if(pid1==0)//供应者1
    {
        int count=0;
        while(count>=0)
        {
            if(count%3==0)//提供吸烟者1缺少的两种原材料
            {
                down(provider1_sem);
                sleep(rate);
                buff1_ptr[0]='B';
                buff1_ptr[1]='C';
                printf("provider1 put B and C to buffer1\n");
                up(smoker1_sem);
            }
            else if(count%3==1)
            {
                down(provider2_sem);
                sleep(rate);
                buff2_ptr[0]='A';
                buff2_ptr[1]='C';
                printf("provider1 put A and C to buffer1\n");
                up(smoker2_sem);
            }
            else if(count%3==2)
            {
                down(provider3_sem);
                sleep(rate);
                buff3_ptr[0]='A';
                buff3_ptr[1]='B';
                printf("provider1 put A and B to buffer1\n");
                up(smoker3_sem);
            }
            count++;
        }

    }
    else//供应者2
    {
        int count=0;
        while(count>=0)
        {
            if(count%3==0)//提供吸烟者1缺少的两种原材料
            {
                down(provider1_sem);
                sleep(rate);
                buff1_ptr[0]='B';
                buff1_ptr[1]='C';
                printf("provider2 put B and C to buffer2\n");
                up(smoker1_sem);
            }
            else if(count%3==1)
            {
                down(provider2_sem);
                sleep(rate);
                buff2_ptr[0]='A';
                buff2_ptr[1]='C';
                printf("provider2 put A and C to buffer2\n");
                up(smoker2_sem);
            }
            else if(count%3==2)
            {
                down(provider3_sem);
                sleep(rate);
                buff3_ptr[0]='A';
                buff3_ptr[1]='B';
                printf("provider2 put A and B to buffer3\n");
                up(smoker3_sem);
            }
            count++;
        }
    }

    return EXIT_SUCCESS;
}
