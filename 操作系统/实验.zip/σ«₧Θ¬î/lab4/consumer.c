#include "ipc.h"



int main(int argc,char *argv[])
{
    int rate; //设置抽烟时间
    if(argv[1] != NULL)	
        rate = atoi(argv[1]);
    else 
        rate = 3;
      
    
    buff1_key = 111; // 缓冲区键值
    buff2_key = 222; // 缓冲区键值
    buff3_key = 333; // 缓冲区键值
    buff_num = 2;   // 缓冲区长度
    shm_flg = IPC_CREAT | 0644;

    // 获取缓冲区使用的共享内存, buff_ptr指向缓冲区首地址
    //A B C 代表三种原材料
    buff1_ptr = (char*)set_shm(buff1_key, buff_num, shm_flg);//存放组合 BC
    buff2_ptr = (char*)set_shm(buff2_key, buff_num, shm_flg);//存放组合 AC
    buff3_ptr = (char*)set_shm(buff3_key, buff_num, shm_flg);//存放组合 AB


    Sem_uns sem_arg1;
    //信号量使用的变量
    smoker1_key = 1001;	//smoker1同步信号量键值
    smoker2_key = 1002;	//smoker2同步信号量键值
    smoker3_key = 1003;	//smoker3同步信号量键值
    provider1_key=2011;
    provider2_key=2012;
    provider3_key=2013;
    
    sem_flg = IPC_CREAT | 0644; //信号量操作权限
    sem_val = 0;
    smoker1_sem = set_sem(smoker1_key,sem_val,sem_flg); 
    sem_arg1.val = sem_val;
    semctl(smoker1_sem,0,SETVAL,sem_arg1) ;
    
    sem_val = 0;
    smoker2_sem = set_sem(smoker2_key,sem_val,sem_flg);
    sem_arg1.val = sem_val;
    semctl(smoker2_sem,0,SETVAL,sem_arg1) ;

    sem_val = 0;
    smoker3_sem = set_sem(smoker3_key,sem_val,sem_flg);
    sem_arg1.val = sem_val;
    semctl(smoker3_sem,0,SETVAL,sem_arg1) ;
    
    sem_val = 1;
    provider1_sem = set_sem(provider1_key,sem_val,sem_flg);
    sem_arg1.val = sem_val;
    semctl(provider1_sem,0,SETVAL,sem_arg1) ;

    sem_val = 1;
    provider2_sem = set_sem(provider2_key,sem_val,sem_flg);
    sem_arg1.val = sem_val;
    semctl(provider2_sem,0,SETVAL,sem_arg1) ;

    sem_val = 1;
    provider3_sem = set_sem(provider3_key,sem_val,sem_flg);
    sem_arg1.val = sem_val;
    semctl(provider3_sem,0,SETVAL,sem_arg1) ;

    int pid1,pid2;

    pid1=fork();
    
    if(pid1==0)//吸烟者1
    {
        while(1)
        {
            //如果原材料充足
            down(smoker1_sem);
            sleep(rate);
            printf("smoker1	get %c and %c from buffer1:\n",buff1_ptr[0],buff1_ptr[1]);
            up(provider1_sem);
        }
    }
    else if(pid1>0)
    {
        pid2=fork();
        if(pid2==0)//吸烟者2
        {
            while(1)
            {
                down(smoker2_sem);
                sleep(rate);
                printf("smoker2	get %c and %c from buffer2:\n",buff2_ptr[0],buff2_ptr[1]);
                up(provider2_sem);

            }
        }
        else//吸烟者3
        {
            while(1)
            {
                down(smoker3_sem);
                sleep(rate);
                printf("smoker3	get %c and %c from buffer3:\n",buff3_ptr[0],buff3_ptr[1]);
                up(provider3_sem);
            }
        }
    }
   

    return EXIT_SUCCESS;
}
