#include  <sys/types.h>
#include  <stdio.h>
#include  <unistd.h>
#include  <string.h>
#include  <stdlib.h>
#include  <wait.h>
#include  <errno.h>
#include  <fcntl.h>
#include  <pwd.h>
#include  <readline/readline.h>  
#include  <readline/history.h>   

/* 用不同的色彩显示用户名与工作目录*/
#define UserNameColor "\033[1m\033[32m"
#define PathColor "\033[1m\033[34m"
#define ColorEnd  "\033[0m"

#define MAX_LINE 255      /* 限定用户输入的命令行长度不超过255字符*/
#define MAX_ARG_LEN 10    /* 命令行参数最大长度*/
#define MAX_ARGC 10       /* 命令行参数最大个数 */

char *getUserName();  /*获取当前用户名*/
char *getUserHomeDirectory();  /* 获取用户根目录，即 /home/用户名*/
/* 函数void getCommandLineArgv(char Command[],char* Arg[]);
   解析输入的命令行，Command中保存命令，Arg[]中依次获取命令行参数
   例如输入命令 ls -l -a，Command=“ls”，arg[0]="ls", arg[1]="-l", 
   arg[2]="-a", arg[3]="--color", 其余 arg[]=NULL */
void getCommandLineArgv(char Command[],char* Arg[]);  
char* LRTrim(char *Str);  /* 去掉字符串Str的前导与尾随空格*/
void Exec_Cd(char *);   /* 处理cd命令，如cd, cd ～, cd .., cd 路径*/
/* 将字符串Str中的所有子串SubStr替换为Replace */
char *SubStrReplace(char *Str, char *SubStr, char *Replace);  

void makepipe(int pipes[][2],int index,char CommandLine[]);

/**************************************
struct passwd *getpwuid(uid_t uid);
The passwd structure is defined in <pwd.h> as follows:
struct passwd {
char *pw_name;   //user name 
char *pw_passwd; //user password
uid_t pw_uid;    //user id 
gid_t pw_gid;    //group id
char *pw_gecos;  //user real name
char *pw_dir;    //home directory
char *pw_shell;  //shell program
};
**************************************/
char *getUserName() //获取用户名
{
    struct passwd *pwd = getpwuid(getuid());
    return pwd->pw_name;
}
char *getUserHomeDirectory() //获取主目录
{
    struct passwd *pwd = getpwuid(getuid());
    return pwd->pw_dir;
}


/*******************************************************************
void getCommandLineArgv(char Command[],char* args[])
e.g Command="ls -l -a", then
command="ls"
args[0]="ls", args[1]="-l", args[2]="a"
args[3]="--color", others args[]=NULL
e.g Command="ps", then
command="ps"
args[0]="ps", args[1]="-t", others args[]=NULL
注1：ls命令自动添加参数--color，是为了实现真正shell执行ls命令的输出效果，
     --color是将目录与可执行文件采用不同的颜色显示
注2：ps命令命令自动添加参数-t， 是为了实现真正shell执行ps命令的输出效果
********************************************************************/
void getCommandLineArgv(char Command[],char* args[])
{
   char *cp=NULL;
   char *str=LRTrim(Command);//去除前导与尾随空格
   char *ch=strchr(str,' ');//返回第一个空格
   int start=1;
   if (ch==NULL)
   {       
      strcpy(args[0],LRTrim(str));
      
      if (strcmp(args[0],"ls")==0)//若两字符串相等
      {
        strcpy(args[1],"--color");
        start=2;
      }
      if (strcmp(args[0],"ps")==0)
      { 
         strcpy(args[1],"-t");
         start=2;
      }
      for (int i=start;i<=MAX_ARGC-1;i++)//其它参数置为空
       args[i]=NULL; 
   }
   else
   {
      int k=0;
      while (ch!=NULL)//记录所有参数
      {
          int n = strlen(str) - strlen(ch); 
        
          strncpy(args[k],str,n);   
          args[k][n]='\0';  
          k++;

          ch=LRTrim(ch);
          strcpy(str,LRTrim(ch));  
          ch=strchr(str,' ');    
      }
      strcpy(args[k],str);
      k=k+1;
      start=k;
      if (strcmp(args[0],"ls")==0)  //ls命令自动添加--color，以色彩显示目录与可执行文件
      {
         strcpy(args[k++],"--color");
         start=k;
      }
      if (strcmp(args[0],"ps")==0)  //如果仅输入命令ps，自动添加参数-t
      { 
        if (k==1)
        {
           strcpy(args[k++],"-t");
           start=k;
        }
      }

      for (int j=start;j<=MAX_ARGC-1;j++)
        args[j]=NULL;
    }
    strcpy(Command,args[0]);
} 
/******************************************
char* LRTrim(char *str)
去掉字符串str的前导与尾随空格
系统调用execve()要求命令与其参数不允许有空格
******************************************/
char* LRTrim(char *str)
{
   while (*str==' ') 
     str++;
   int len=strlen(str)-1;
   while (str[len]==' ')
     len--;
   str[len+1]='\0';
   return str;
}

/********************************************
int Exec_Cd(char *Command)
命令cd是一个内置命令，不能利用exec执行，需要
单独处理, cd, cd .., cd ~, cd 路径名 等
********************************************/
void Exec_Cd(char *Command)
{
   char NewPath[MAX_LINE];
   char *str=LRTrim(Command);
   if (strstr(str,"..")!=NULL)//返回上一级
   {
      char *CurrentPath=getcwd(NULL,0);//得到工作目录
      char *p=strrchr(CurrentPath,'/');
      if (p==NULL)
         return;
      int n=strlen(CurrentPath)-strlen(p);
      strncpy(NewPath,CurrentPath,n);
      NewPath[n]='\0';
   }
   else if ((strstr(str,"~")!=NULL) || (strcmp(str,"cd")==0))//切换到主目录
   {
      strcpy(NewPath,getUserHomeDirectory());
   }
   else
   {
      str=str+2;  //get the path followed "cd"
      strcpy(NewPath,LRTrim(str));
   }
   if (access(NewPath,F_OK)==0)
      chdir(NewPath);//更换当前的工作目录
}
/**********************************************************
char *SubStrReplace(char *Str, char *SubStr, char *Replace)
* 将字符串Str中的所有子串SubStr替换为Replace 
**********************************************************/
char *SubStrReplace(char *Str, char *SubStr, char *Replace)
{
   char *ret=strstr(Str,SubStr);
   if (ret==NULL) //SubStr is not in Str
     return Str;   

   char NewStr[256];  
   int n = strlen(Str) - strlen(ret);
    
   strncpy(NewStr,Str,n);
   NewStr[n]='\0';
   
   strcat(NewStr,Replace);

   for (int i=1;i<=strlen(SubStr);i++)
      ret=ret+1;  

   strcat(NewStr,ret); 
   
   return SubStrReplace(NewStr,SubStr,Replace);
}

void Redirctory(char* Exec_Argv[])
{
   for(int i=0;Exec_Argv[i]!=NULL;i++)//io重定向
   {
      if(strcmp(Exec_Argv[i],">")==0)//重定向标准输出
      {
         i++;
         int fd=open(Exec_Argv[i],O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
         if (fd < 0) {
            perror("Failed to open file");
            exit(-1);
         }
         int oldStdout = dup(1); 
         close(1);
         int newStdout=dup(fd);
         //删除多余参数
         Exec_Argv[i-1]=NULL;
         Exec_Argv[i]=NULL;
      }

         else if(strcmp(Exec_Argv[i],"2>")==0)//将错误输出重定向到文件中（清除原有文件中的数据）
         {
            i++;
            int fd=open(Exec_Argv[i],O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
            if (fd < 0) {
               perror("Failed to open file");
               exit(-1);
            }
            int oldStdout = dup(2); 
            close(2);
            int newStdout=dup(fd);
            Exec_Argv[i]=NULL;
            Exec_Argv[i-1]=NULL;
         }

         else if(strcmp(Exec_Argv[i],"&>")==0)//将标准输出与错误输出都重定向到文件中（清除原有文件中的数据）
         {
            i++;
            int fd=open(Exec_Argv[i],O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
            if (fd < 0) {
               perror("Failed to open file");
               exit(-1);
            }
            int oldStdout = dup(2); 
            close(1);
            close(2);
            int newStdout=dup(fd);
            dup(fd);
            Exec_Argv[i]=NULL;
            Exec_Argv[i-1]=NULL;
         }

         else if(strcmp(Exec_Argv[i],">>")==0)//将标准输出重定向到文件中（在原有的内容后追加）
         {
            i++;
            int fd=open(Exec_Argv[i],O_RDWR|O_CREAT|O_APPEND,S_IRWXU);
            if (fd < 0) {
               perror("Failed to open file");
               exit(-1);
            }
            int oldStdout = dup(1); 
            close(1);
            int newStdout=dup(fd);
            Exec_Argv[i]=NULL;
            Exec_Argv[i-1]=NULL;
         }

         else if(strcmp(Exec_Argv[i],"2>>")==0)//将错误输出重定向到文件中（在原有内容后面追加）
         {
            i++;
            int fd=open(Exec_Argv[i],O_RDWR|O_CREAT|O_APPEND,S_IRWXU);
            if (fd < 0) {
               perror("Failed to open file");
               exit(-1);
            }
            int oldStdout = dup(2); 
            close(2);
            int newStdout=dup(fd);
            Exec_Argv[i]=NULL;
            Exec_Argv[i-1]=NULL;
         }

         else if(strcmp(Exec_Argv[i],"&>>")==0)//标准输出和错误输出都写入文件（在原有内容后追加）
         {
            i++;
            int fd=open(Exec_Argv[i],O_RDWR|O_CREAT|O_APPEND,S_IRWXU);
            if (fd < 0) {
               perror("Failed to open file");
               exit(-1);
            }
            int oldStdout = dup(1); 
            int oldstderr=dup(2);
            close(1);
            close(2);
            int newStdout=dup(fd);
            dup(fd);
            Exec_Argv[i]=NULL;
            Exec_Argv[i-1]=NULL;
         }

         //标准输入重定向
         else if(strcmp(Exec_Argv[i],"<")==0)//将”文件”作为命令的标准输入
         {
            i++;
            int fd=open(Exec_Argv[i],O_RDONLY|O_CREAT,S_IRWXU);
            if (fd < 0) {
                  perror("Failed to open file");
                  exit(-1);
            }
            int oldStdout = dup(0); 
            close(0);
            int newStdout=dup(fd);
            Exec_Argv[i]=NULL;
            Exec_Argv[i-1]=NULL;
         }

         else if(strcmp(Exec_Argv[i],"<<")==0)//标准输入中读入，直到遇到“分界符”停止。例如：命令<<END：输入的每个数据用回车分隔，直到输入分界符END为止。
         {
            i++;
            int fd1=open("infile.txt",O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
            if (fd1 < 0) {
                perror("Failed to open file");
                exit(-1);
            }

            while(1)
            {

               int same=1;//判断是否读到end
               char c;
               int j=0;
               while((c=getchar())!='\n')
               {
                  write(fd1, &c, 1);
                  if(Exec_Argv[i][j] != c)
                  {
                     same = 0;
                  }
                  if(j<strlen(Exec_Argv[i])-1)
                     j++;
                  }
                  write(fd1, "\n", 1);
                  if(same) break;//读到end
               }

               close(fd1);

               int fd2=open("infile.txt",O_RDONLY|O_CREAT,S_IRWXU);
               if (fd2 < 0) {
                  perror("Failed to open file");
                  exit(-1);
               }
               
               int oldStdout = dup(0); 
               close(0);
               int newStdout=dup(fd2);
               
               Exec_Argv[i]=NULL;
               Exec_Argv[i-1]=NULL;
            }
         }
}

void makepipe(int pipes[][2],int index,char CommandLine[])
{
   char* flag=strchr(CommandLine,'|');
   char command1[MAX_LINE+1];
   char ArgvBuffer[MAX_ARGC][MAX_ARG_LEN];
   char *Argv1[MAX_ARGC];
   for (int i=0;i<=MAX_ARGC-1;i++)
         Argv1[i]=ArgvBuffer[i];
   

   if(flag==NULL)
   {
      int n = strlen(CommandLine);      
      strncpy(command1,CommandLine,n);   
      command1[n]='\0';
      getCommandLineArgv(command1,Argv1);

      int pid=fork();
      if(pid==0)
      {
         Redirctory(Argv1);

         if(index>0)
         {
            close(0);
            dup(pipes[index-1][0]);  //标准输入定向到管道的读端
            close(pipes[index-1][0]);
            execvp(command1,Argv1); 
         }

      }
      else
      {
         waitpid(pid, NULL, 0);
         return;
      }
   }

   else//剩余命令中还有管道命令
   {
      int n = strlen(CommandLine)-strlen(flag);
      strncpy(command1,CommandLine,n);   
      command1[n]='\0';
      getCommandLineArgv(command1,Argv1);

      strcpy(CommandLine,flag);   
      CommandLine=CommandLine+1;



      pipe(pipes[index]);//pipes[index][0]用于读管道,pipes[index]用于写管道

      int pid=fork();

      if (pid==0)  /* 处理管道左部分  command1*/
      {
         
         Redirctory(Argv1);
         close(1);
         dup(pipes[index][1]);  //标准输出定向到管道的写端
         close(pipes[index][1]);
     
         if(index>0)
         {
            close(0);
            dup(pipes[index-1][0]);  //标准输入定向到管道的读端
            close(pipes[index-1][0]);
         }  
         
         execvp(command1,Argv1); 
      }
      else if(pid>0)
      {
         waitpid(pid, NULL, 0);
         close(pipes[index][1]);
         
      }
   }
      
}
   /*
    ls &
    ps
    pwd
    cd ..
    sudo su
   
   
    cat 1.txt
    abc

   echo somthing > 1.txt

   ls -la > 1.txt
   ./msh << 123   从标准输入读取直到读到123为止 
   ./msh > 2.txt < 1.txt    将1.txt输入，输出到2.txt
   ./msh >> 2.txt << 123    输出到2.txt追加
   ./msh 2> 2.txt << 123    输出标准错误信息到2.txt清空  并从标准输入的内容读取
   ./msh &>> 2.txt < 1.txt     标准输出和错误输出都到2.txt，追加的
   */
    

/*
   echo hello | ./test > 1.txt
    echo hello | ./test
    echo hello | ./test | ./test | ./test
*/