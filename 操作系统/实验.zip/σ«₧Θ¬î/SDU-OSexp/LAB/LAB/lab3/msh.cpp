#include<iostream>
#include<string>
 
using namespace std;

int main()
{
    char c;
    
    while((c = getchar()) != EOF) {
        putchar(c); // 将输入字符逐个输出
    }
        
}