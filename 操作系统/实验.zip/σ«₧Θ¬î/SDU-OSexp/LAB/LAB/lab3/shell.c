#include "shell.h"
int main()
{  
   pid_t pid, RetPid;
   int exec_ret;
   char c, *AmperSand=&c;
   int background=0;   /* 如果命令行的最后字符是&，则后台运行background=1 */
      
    char CommandLine_Buffer[MAX_LINE+1];
    char *CommandLine=CommandLine_Buffer;
   /*****************************************/
    char Command[MAX_LINE+1];
    char ArgvBuffer[MAX_ARGC][MAX_ARG_LEN];
    char *Exec_Argv[MAX_ARGC];   
    int Pipes[MAX_ARGC][2];
  /******************************************/
 
   while (1) 
   {
      //设置readline的提示信息
      char *dollar="$ "; /*对于一般用户，用$提示*/
      char prompt[200]=UserNameColor; /*绿色高亮度显示用户名*/
      char *UserName=getUserName();
      if (strcmp(UserName,"root")==0)
         dollar="# "; /*对于root用户，用#提示*/
      strcat(prompt,UserName);
      strcat(prompt,":");
      strcat(prompt,PathColor);/*蓝色高亮度显示工作目录*/        
      char* homeDirecrory=getUserHomeDirectory();
      //用户主目录用显示为～
      char* path=SubStrReplace(getcwd(NULL,0), homeDirecrory, "~");
      strcat(prompt,path);       
      strcat(prompt,ColorEnd); /*后续字符不采用色彩输出*/
      strcat(prompt,dollar);

      /*读取键盘输入的命令行 */
      CommandLine=readline(prompt);
      /*去掉命令行的前导与尾随空格 */
      strcpy(CommandLine,LRTrim(CommandLine));
      /*如果没有输入命令，仅仅按下回车键 */
      if (strlen(CommandLine)==0)
         continue;
      /*将读取的命令添加到历史命令缓存*/
      add_history(CommandLine);

      //处理cd命令 
      if (strncmp(CommandLine,"cd",2)==0) //比较前两个字符是否相等
      {
         Exec_Cd(CommandLine);
         continue;
      }

      //判断是否要求后台运行
      AmperSand=strchr(CommandLine,'&');
      if (AmperSand!=NULL&&*(AmperSand+1)=='\0') //要求后台运行
      { 
         background=1;
	      int n=strlen(CommandLine)-strlen(AmperSand);
	      strncpy(Command,CommandLine,n);
	      Command[n]='\0';
         strcpy(Command,LRTrim(Command));   
      }
	   else //不要求后台运行
      { 
	      background=0;
	      strcpy(Command,LRTrim(CommandLine));
      } 
        
      //判断是否有管道
      AmperSand=strchr(CommandLine,'|');
      if (AmperSand!=NULL) //有
      { 
         makepipe(Pipes,0,CommandLine);
         continue;
      }

      /*初始化命令行参数字符串 */
      for (int i=0;i<=MAX_ARGC-1;i++)
         Exec_Argv[i]=ArgvBuffer[i];
      /*解析输入的命令行，分解命令与命令参数*/
      getCommandLineArgv(Command,Exec_Argv);
       
      if ((pid=fork())<0) //创建子进程
      {
	      printf("Call fork failure\n");
	      exit(-1);
	   }
	   if (pid==0)  /*子进程执行命令行输入的命令*/
      {

         // for(int i=0;Exec_Argv[i]!=NULL;i++)//io重定向
         // {
         //    if(strcmp(Exec_Argv[i],">")==0)//重定向标准输出
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(1); 
         //       close(1);
         //       int newStdout=dup(fd);
         //       删除多余参数
         //       Exec_Argv[i-1]=NULL;
         //       Exec_Argv[i]=NULL;
         //    }

         //    else if(strcmp(Exec_Argv[i],"2>")==0)//将错误输出重定向到文件中（清除原有文件中的数据）
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(2); 
         //       close(2);
         //       int newStdout=dup(fd);
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         //    else if(strcmp(Exec_Argv[i],"&>")==0)//将标准输出与错误输出都重定向到文件中（清除原有文件中的数据）
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(2); 
         //       close(1);
         //       close(2);
         //       int newStdout=dup(fd);
         //       dup(fd);
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         //    else if(strcmp(Exec_Argv[i],">>")==0)//将标准输出重定向到文件中（在原有的内容后追加）
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_RDWR|O_CREAT|O_APPEND,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(1); 
         //       close(1);
         //       int newStdout=dup(fd);
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         //    else if(strcmp(Exec_Argv[i],"2>>")==0)//将错误输出重定向到文件中（在原有内容后面追加）
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_RDWR|O_CREAT|O_APPEND,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(2); 
         //       close(2);
         //       int newStdout=dup(fd);
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         //    else if(strcmp(Exec_Argv[i],"&>>")==0)//标准输出和错误输出都写入文件（在原有内容后追加）
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_RDWR|O_CREAT|O_APPEND,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(1); 
         //       int oldstderr=dup(2);
         //       close(1);
         //       close(2);
         //       int newStdout=dup(fd);
         //       dup(fd);
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         //    标准输入重定向
         //    else if(strcmp(Exec_Argv[i],"<")==0)//将”文件”作为命令的标准输入
         //    {
         //       i++;
         //       int fd=open(Exec_Argv[i],O_RDONLY|O_CREAT,S_IRWXU);
         //       if (fd < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(0); 
         //       close(0);
         //       int newStdout=dup(fd);
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         //    else if(strcmp(Exec_Argv[i],"<<")==0)//标准输入中读入，直到遇到“分界符”停止。例如：命令<<END：输入的每个数据用回车分隔，直到输入分界符END为止。
         //    {
         //       i++;
         //       int fd1=open("infile.txt",O_WRONLY|O_TRUNC|O_CREAT,S_IRWXU);
         //       if (fd1 < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }

         //       while(1)
         //       {

         //          int same=1;//判断是否读到end
         //          char c;
         //          int j=0;
         //          while((c=getchar())!='\n')
         //          {
         //             write(fd1, &c, 1);
         //             if(Exec_Argv[i][j] != c)
         //             {
         //                same = 0;
         //             }
         //             if(j<strlen(Exec_Argv[i])-1)
         //                j++;
         //          }
         //          write(fd1, "\n", 1);
         //          if(same) break;//读到end
                  

         //       }
         //       close(fd1);


         //       int fd2=open("infile.txt",O_RDONLY|O_CREAT,S_IRWXU);
         //       if (fd2 < 0) {
         //           perror("Failed to open file");
         //           exit(-1);
         //       }
         //       int oldStdout = dup(0); 
         //       close(0);
         //       int newStdout=dup(fd2);


               
         //       Exec_Argv[i]=NULL;
         //       Exec_Argv[i-1]=NULL;
         //    }

         // }

         Redirctory(Exec_Argv);


         /* 执行输入的命令 */
         exec_ret=execvp(Command,Exec_Argv);
             
         if (exec_ret<0) 
         {
            switch(errno)
            {
               case ENOENT: /* 要执行的命令文件不存在*/
                  printf("%s: Command not found! \n",Command);
                  exit(0);
               case EACCES: /* 要执行的命令文件无访问权限*/
                  printf("%s: permition Denied! \n",Command);
                  exit(0);
            }
         }
      }
      else if (pid>0)  //父进程
      {
         if (!background)  /* 不要求后台运行，父进程等待子进程执行命令结束*/
             RetPid=wait(NULL);
      }
   }
}


 