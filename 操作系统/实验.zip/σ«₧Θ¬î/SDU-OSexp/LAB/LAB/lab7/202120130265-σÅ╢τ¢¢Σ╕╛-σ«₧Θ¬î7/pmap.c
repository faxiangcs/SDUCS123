#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
	
int main()
{
	int data[13];
    int pid;
	char filename[PATH_MAX];
	char pname[PATH_MAX];
	unsigned long mapped = 0, private= 0, shared = 0;
	FILE *fp;
	printf("请输入进程号和进行的操作\n");
	scanf("%d",&pid);
	char c;
	c=getchar();
	c=getchar();
	c=getchar();
	sprintf(filename, "/proc/%ld/cmdline", (long) pid);
	fp=fopen(filename, "r");
	if(!fp)
	{
		perror("can't open file\n");
		return 0;
	}
	//输出程序名称
	int i=0;
	while(1)
	{
		pname[i]=getc(fp);
		if(pname[i]==EOF)
			break;
		i++;
	}
	pname[i]='\0';
	printf("%s(%d)\n", pname, pid);	// 输出程序名称
    fclose(fp);

	//输出map
	sprintf(filename, "/proc/%ld/smaps", (long)pid);
    fp = fopen(filename, "r");
	if(!fp)
	{
		perror("can't open file\n");
		return 0;
	}
	if(c=='x')
	{
		int m=0;
		m = printf("begin          size");
		m += printf("%*s RSS",22-m, "");
		m += printf("%*s Dirty",32-m, "");
		m += printf("%*s Mode   dev  inode ", 42-m, "");
		printf("%*s  Maping\n", 65-m, "");
		while(!feof(fp)) 
		{		
			char buf[PATH_MAX+100], perm[5], dev[6], mapname[PATH_MAX];
			int RSS,dirty;
			dirty=0;
			// 地址、权限、设备号、映射的文件名/RSS(实际占用的物理内存) dirty/
			unsigned long begin, end, size, inode, offset;
			int n;

			for(int i=1;i<=23;i++)
			{
				if(fgets(buf, sizeof(buf), fp) == 0)
				{
					break;
				}
					
				if(i==1)
				{
					mapname[0] = '\0';
					sscanf(buf, "%lx-%lx %4s %lx %5s %ld %s", 
					&begin, &end, perm,&offset, dev, &inode, mapname);
					size = end - begin;
					mapped += size;
					if(perm[3] == 'p') 
					{
						if(perm[1] == 'w')
						private += size;
					} 
					else if(perm[3] == 's')
					shared += size;
				}
				else if(i==5)
				{
					sscanf(buf, "Rss: %d",&RSS);
				}
				else if(i==8)
				{
					int d;
					sscanf(buf, "Shared_Dirty: %d",&d);
					dirty+=d;
				}
				else if(i==10)
				{
					int d;
					sscanf(buf, "Private_Dirty: %d",&d);
					dirty+=d;
				}

			}
			
			n = printf("%08lx (%ld KB)", begin,size/1024);
			n += printf("%*s %d KB",22-n, "",RSS);
			n += printf("%*s %d KB",32-n, "",dirty);
			n += printf("%*s %s (%s %ld) ", 42-n, "", perm, dev, inode);
			printf("%*s %s\n", 65-n, "", mapname);
		}

		printf("mapped:   %ld KB private/writable: %ld KB shared: %ld KB\n",mapped/1024, private/1024, shared/1024);
		fclose(fp);
	}
	else if(c=='X')
	{
		printf("Address      Perm  Offset  Device Inode  Size    Rss  Pss Referenced Anonymous LazyFree ShmemPmdMapped FilePmdMapped Shared_Hugetlb Private_Hugetlb Swap SwapPss Locked THPeligible Mapping\n");
		while(!feof(fp)) 
		{		
			char buf[PATH_MAX+100], perm[5], dev[6], mapname[PATH_MAX];
			char buf1[100];
			// 地址、权限、设备号、映射的文件名/RSS(实际占用的物理内存) dirty/
			unsigned long begin, end, size, inode, offset;
			int n;
			int count=0;
			for(int i=1;i<=23;i++)
			{
				
				if(fgets(buf, sizeof(buf), fp) == 0)
				{
					break;
				}
					
				if(i==1)
				{
					mapname[0] = '\0';
					sscanf(buf, "%lx-%lx %4s %lx %5s %ld %s", 
					&begin, &end, perm,&offset, dev, &inode, mapname);
					size = end - begin;
					mapped += size;
					if(perm[3] == 'p') 
					{
						if(perm[1] == 'w')
						private += size;
					} 
					else if(perm[3] == 's')
					shared += size;
				}
				else if(i==2||i==3||i==4||i==7||i==9||i==8||i==10||i==14||i==23)
				{
					continue;
				}
				else
				{
					sscanf(buf, "%s %d",buf1,&data[count]);
					count++;
				}

			}

			
			n = printf("%08lx %s", begin,perm);
			n += printf(" %ld ",offset);
			n += printf("%*s %s ", 26-n, "", dev);
			n += printf("%*s %ld", 33-n, "", inode);
			n += printf("%*s %ld", 40-n, "", size);

			n += printf("%*s %d", 48-n, "", data[0]);
			n += printf("%*s %d", 53-n, "", data[1]);
			n += printf("%*s %d", 58-n, "", data[2]);
			n += printf("%*s %d", 70-n, "", data[3]);
			n += printf("%*s %d", 80-n, "", data[4]);
			n += printf("%*s %d", 95-n, "", data[5]);
			n += printf("%*s %d", 110-n, "", data[6]);
			n += printf("%*s %d", 122-n, "", data[7]);
			n += printf("%*s %d", 135-n, "", data[8]);
			n += printf("%*s %d", 148-n, "", data[9]);
			n += printf("%*s %d", 155-n, "", data[10]);
			n += printf("%*s %d", 162-n, "", data[11]);
			n += printf("%*s %d", 172-n, "", data[12]);

			// for(int i=0;i<=12;i++)
			// {
			// 	n += printf("%8d ",data[i]);
			// }

			printf("%*s %s\n", 175-n, "", mapname);
		}

		printf("mapped:   %ld KB private/writable: %ld KB shared: %ld KB\n",mapped/1024, private/1024, shared/1024);
		fclose(fp);
	}
	else
	{
		printf("请输入正确的命令！\n");
	}
	
}