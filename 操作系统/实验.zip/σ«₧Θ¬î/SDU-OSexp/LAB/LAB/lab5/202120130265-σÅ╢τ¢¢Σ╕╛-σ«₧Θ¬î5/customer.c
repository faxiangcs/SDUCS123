#include "ipc.h"
#include<sys/errno.h>

int main(int argc,char *argv[])
{
    int rate;
    Msg_buf msg_arg;
    //可在在命令行第一参数指定一个进程睡眠秒数,以调解进程执行速度
    if(argv[1] != NULL) 
    rate = atoi(argv[1]);
    else rate = 3;
            
    //建立一个请求消息队列
    quest_flg = IPC_CREAT| 0644;
    quest_key = 101;
    quest_id = set_msq(quest_key,quest_flg);

    //建立一个响应消息队列
    respond_flg = IPC_CREAT| 0644;
    respond_key = 201;
    respond_id = set_msq(respond_key,respond_flg);

    Sem_uns sem_arg1;
    pay_key = 1001;	//
    sem_flg = IPC_CREAT | 0644; //信号量操作权限
    sem_val = 1;
    pay = set_sem(pay_key,sem_val,sem_flg);
    sem_arg1.val = sem_val;
    semctl(pay,0,SETVAL,sem_arg1);


      while(msgrcv(respond_id, &msg_arg, sizeof(msg_arg), 0, IPC_NOWAIT)!=-1)
      { 
      }
      while(msgrcv(quest_id, &msg_arg, sizeof(msg_arg), 0, IPC_NOWAIT)!=-1)
      { 
      }



    int sofa=0;
    int room=0;
    int id=0;

    while(1) 
    {

      sleep(rate);
      id++;
      msg_arg.mid = id;

      if(sofa < 4)//沙发有空余位置
      {
            if(room!= 0)
            {
                //阻塞方式接收消息
                msgrcv(quest_id, &msg_arg, sizeof(msg_arg), SOFA, 0);//等待时间最长的顾客坐沙发
                printf("%d customer from waiting room to sofa\n", msg_arg.mid);

                
                msg_arg.mtype=HAIR;//发送理发请求
                sofa++;
                msgsnd(quest_id, &msg_arg, sizeof(msg_arg), 0);

                msg_arg.mid = id;//新来顾客发送沙发请求
                msg_arg.mtype=SOFA;
                msgsnd(quest_id, &msg_arg,sizeof(msg_arg), 0);   
                printf("sofa is full %d customer is in the waiting room\n", id);
                  

            } 
            else if(room==0)//直接坐在沙发
            {
                printf("%d customer sit on the sofa.\n", id);

                msg_arg.mid = id;
                msg_arg.mtype=HAIR;
                sofa++;
                msgsnd(quest_id, &msg_arg, sizeof(msg_arg), 0);//发出理发请求
            }    

      } 
	else if(room < 13) 
      {
            printf("sofa is full %d customer is in the waiting room\n", id);
            msg_arg.mid = id;
            msg_arg.mtype=SOFA;
            msgsnd(quest_id, &msg_arg, sizeof(msg_arg), 0);
            room++;
      } 
      else 
      {
            printf("waiting room is full %d customer can't get into barber shop\n", id);
            
            msgrcv(respond_id, &msg_arg, sizeof(msg_arg), HAIR, 0);//等待某位顾客离开沙发开始理发
            printf("customer %d is having a haircut\n",msg_arg.mid);
            sofa--;
            id--;
            
      }
      
      while(msgrcv(respond_id, &msg_arg, sizeof(msg_arg), HAIR, IPC_NOWAIT)!=-1)//有顾客离开沙发去理发
      { 
            printf("customer %d is having a haircut\n",msg_arg.mid);
            sofa--;
      }
      while(sofa<4&&room>0)
      {
            msgrcv(quest_id, &msg_arg, sizeof(msg_arg), SOFA, IPC_NOWAIT);
            printf("%d customer from waiting room to sofa\n",msg_arg.mid);
            msg_arg.mtype=HAIR;//发送理发请求
            msgsnd(quest_id, &msg_arg, sizeof(msg_arg), 0);
            sofa++;
            room--;
      }


    }

    return 0;
}
