select * from student;
update student set major = 'Electrical Engineering' where id = 2;
select * from student;
delete from student where name = 'Jack';
select * from student;
update student set major = 'Computer Science' where id = 2;
select * from student;
insert into student values (3, 'Jack', 'Electrical Engineering');
select * from student;
