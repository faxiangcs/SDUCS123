#include "ownbase.h"

int main(int argc, char *argv[]) { return ownbase_start(argc, argv); }