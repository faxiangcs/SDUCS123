#include "checkpoint.h"

void CheckpointManager::BeginCheckpoint() {}

void CheckpointManager::EndCheckpoint() {}