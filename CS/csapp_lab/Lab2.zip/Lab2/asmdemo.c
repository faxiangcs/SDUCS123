#include <stdio.h>
#include <stdlib.h>
//gcc -Og -no-pie -fno-PIC -fno-omit-frame-pointer -fno-stack-protector -ggdb -fcf-protection=none  -mmanual-endbr asmdemo.c -o asmdemo
/*选项说明
  -ggdb 用于产生 GDB 特有的调试信息,可执行文件的尺寸会大大增加。
  -fcf-protection=none和 -mmanual-endbr用来消除 endbr32汇编指令。endbr32主要是开启CET-IBT机制，缓解COP/JOP 攻击。
*/ 
int ssum(int x1,int x2,int x3,int x4,int x5,int x6,int x7,int x8)
{
    return x1+x2+x3+x4+x5+x6+x7+x8;
}

int sum(int arr[],int n)
{
   int res=0;
   int i;

   for(i=0;i<n;i++)
        res+=arr[i];

   //for(i=n-1;i>=0;i--)
       //res+=arr[i];

   return res;
}


int sump(int *arr,int n)
{
   int res=0;
   int i;

   for(i=0;i<n;i++)
         res=res+ *(arr+i);

   return res;
}


void swap(int *x, int *y)
{
	int t;

	t = (*y);
	(*y) = (*x);
	(*x) = t;
}


void swape(int *x, int y)
{
	int t;

	t = y;
	y = (*x);
	(*x) = t;
}


void swapb(int x, int y)
{
	int t;

	t = y;
	y = x;
	x = t;
}

int absi(int n)
{
    if(n<0)
       n=-n;
    return  n;
}


int logicval(int n)
{
    if(n!=0)
       n=1;
    return  n;
}

int  ti(int n)
{
    if(n>100)
       n=100;
    else if(n<-100)
       n=-100;
    return  n;
}

int updown(char *name,int n)
{
    char t,nm[20];
    int i,j,l;

    strcpy(nm,name);
    l=strlen(nm);
    if(l<2)
       return 0;

    for(i=0,j=l-1;i<l/2;i++,j--)
    {
       t=nm[i];
       nm[i]=nm[j];
       nm[j]=t;
    }
    printf("%s\n",nm);
    return 1;
}

int m=3;
char name[10]="abcdefg";
int res=0;
int x=1;
int y=2;

int main()
{
    int x = 100*4;
    int y ;
    int i=0;
    int j=-100;
    int a[10]={1,2,3,4,5,6,7,8,9,10};
    int iSum;
    y=x*2;

	iSum=ssum(1,x,a[3],a[4],y,m,-10,0);
    printf("iSum=%d\n",iSum);

    printf("%d\n",absi(y));
    printf("%d\n",logicval(y));
    printf("%d\n",ti(y));

    swape(&x, y);
    printf("%d %d\n",x,y);
    swap(&x, &y);
    printf("%d %d\n",x,y);
    swapb(x, y);
    printf("%d %d\n",x,y);

    printf("%d\n",sum(a,10));
    updown(name,7);
    printf("%s\n",name);

    m=m*y*j;
    switch(m)
    {
       case 1:  printf("zero!\n");break;
       case 2:  printf("one!\n");break;
       case 3:  printf("two!\n");break;
       case 4:  printf("three!\n");break;
       case 5:  printf("four!\n");break;
       case 6:  printf("five!\n");break;
       default: printf("other!\n");break;
    }

	getchar();
	return 0;
}