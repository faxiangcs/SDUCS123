#include <stdio.h>

// �ݹ�ʵ��sum1(n)
int sum1(int n) {
    if (n == 1) {
        return 1;
    } else {
        return n + sum1(n - 1);
    }
}

int sum2(int n) {
    if (n == 1) {
        return 1;
    } else {
        return sum2(n - 1) + n;
    }
}

int main() {
    int n;
    for(n=65534;n<10000000;n++)
    {
	        sum1(n);
		printf("sum1(%d) = %d\n", n,sum1(n));
		//printf("sum2(%d) = %d\n", n, sum2(n));
	}
    

    return 0;
}
