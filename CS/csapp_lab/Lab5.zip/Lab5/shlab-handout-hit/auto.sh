silent=0
if [ $# -eq 2 ]
then
    tshref=$1
    tsh0=$2
elif [ $# -eq 3 ]
then
    if [ $1 == "-s" ]
    then
        silent=1
        tshref=$2
        tsh0=$3
    else
        tshref=$1
        if [ $2 == "-s" ]
        then
            tsh0=$3
            silent=1
        elif [ $3 == "-s" ]
        then
            tsh0=$2
            silent=1
        else
            echo "Wrong input!"
            exit
        fi
    fi
elif [ $# -eq 0 ]
then
    tshref="tshref"
    tsh0="tsh0"
elif [ $# -eq 1 -a $1 == "-s" ]
then
    tshref="tshref"
    tsh0="tsh0"
    silent=1
else
    echo "Wrong input!"
    exit
fi

for skill in 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16; do
    echo -e "\033[31m"
    echo -e "trace${skill}\n"

    echo -e "\033[32m"
    ./sdriver.pl -t trace${skill}.txt -s ./${tshref} -a "-p"
    echo -e "\n\n"

    echo -e "\033[34m"
    ./sdriver.pl -t trace${skill}.txt -s ./${tsh0} -a "-p"
    echo -e "\n\n"

    echo -e "\033[0m"

    if [ $silent -eq 0 ]
    then
        read -s -n1 -p "Press any key to continue..."
        echo -e "\n\n"
    fi
done

